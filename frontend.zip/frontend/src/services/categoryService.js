import apiClient from './api';
import { resolveServiceImage, resolveCategoryImage } from '../utils/imageResolver';

export const categoryService = {
  // =========================
  // GET ALL CATEGORIES
  // =========================
  getCategories: async () => {
    const response = await apiClient.get('/categories');
    return response.data.map((category) => {
      const slug = category.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      return {
        id: category.id,
        name: category.name,
        slug,
        icon: category.iconUrl || '🔧',
        iconUrl: category.iconUrl || '🔧',
        image: resolveCategoryImage(category.name),
        description: category.description,
        providerCount: 4,
        active: category.active !== false,
      };
    });
  },

  // =========================
  // GET SERVICES BY CATEGORY ID OR ALL
  // =========================
  getServices: async (filters = {}) => {
    let url = '/services/active';

    if (
      filters.categoryId !== undefined &&
      filters.categoryId !== null &&
      filters.categoryId !== '' &&
      filters.categoryId !== 'all'
    ) {
      url = `/services/category/${filters.categoryId}`;
    }

    const response = await apiClient.get(url);
    let result = Array.isArray(response.data) ? response.data : [];

    // Search filter
    if (filters.search) {
      const q = filters.search.toLowerCase().trim();
      result = result.filter(
        (service) =>
          service.name?.toLowerCase().includes(q) ||
          service.description?.toLowerCase().includes(q) ||
          service.categoryName?.toLowerCase().includes(q)
      );
    }

    return result.map((service) => {
      const resolvedImg = resolveServiceImage(service);
      return {
        id: service.id,
        name: service.name,
        description: service.description,
        shortDescription: service.description,
        basePrice: service.basePrice,
        price: service.basePrice,
        startingPrice: service.basePrice,
        durationInMinutes: service.durationInMinutes || 60,
        durationMinutes: service.durationInMinutes || 60,
        categoryId: service.categoryId,
        categoryName: service.categoryName,
        image: resolvedImg,
        imageUrl: resolvedImg,
        rating: 4.8,
        reviewCount: 18,
        providerCount: 3,
        included: [
          "Certified technician doorstep visit",
          "Complete diagnosis and safety inspection",
          "Labor for standard repair & testing",
          "Post-service cleanup & guarantee check"
        ],
        excluded: [
          "Replacement spare parts and hardware billed separately",
          "Major structural masonry or concealed cable cutting"
        ],
        active: service.active,
        createdAt: service.createdAt,
        updatedAt: service.updatedAt,
      };
    });
  },

  // =========================
  // GET SERVICE BY ID
  // =========================
  getServiceById: async (id) => {
    const response = await apiClient.get(`/services/${id}`);
    const service = response.data;
    const resolvedImg = resolveServiceImage(service);

    return {
      id: service.id,
      name: service.name,
      description: service.description,
      shortDescription: service.description,
      basePrice: service.basePrice,
      price: service.basePrice,
      durationInMinutes: service.durationInMinutes || 60,
      categoryId: service.categoryId,
      categoryName: service.categoryName,
      image: resolvedImg,
      imageUrl: resolvedImg,
      active: service.active,
      createdAt: service.createdAt,
      updatedAt: service.updatedAt,
    };
  },
};